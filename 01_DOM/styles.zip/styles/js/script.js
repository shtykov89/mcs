console.log('you are at '+window.location);

const colored = document.querySelector('.colored');
console.log(colored);